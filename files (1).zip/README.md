# GreenCampus: Smart Classroom & Timetable Scheduler (Web App)

Frontend for the Flask backend (Parts 1 and 2). It reads and writes real data through the API, builds a clash-free timetable, and falls back to demo data when the backend is offline.

## Run

1. Start the backend: `cd backend`, activate the venv, `python run.py` (http://localhost:5000).
2. In the backend `.env`, allow this app's origin, then restart the backend:
   `CORS_ORIGINS=http://localhost:5173,http://localhost:5500`
3. Serve this folder (do not double-click `index.html`, the browser blocks API calls from `file://`):
   `python -m http.server 5500`, then open http://localhost:5500.

The pill at the top shows **Backend connected** or **Demo mode (offline)**. Click it to change the API URL (default `http://localhost:5000/api`) or reset demo data.

## What is connected

| Screen | Backend calls |
| --- | --- |
| Manage data | `GET/POST/PATCH/DELETE` on `/api/subjects`, `/faculty`, `/classrooms`, `/student-groups`, `/time-slots` |
| Assign subjects | `GET/POST /api/faculty/<id>/subjects`, `DELETE .../subjects/<sid>`, same for `/student-groups` |
| Startup | `GET /api/health`, then every list with `?page=N&per_page=100` |

Validation errors from the API (`details`) are shown inside the form. Rooms, people, dashboard stats, insights and the green score are all computed from this data.

## Timetable generation

Parts 3 to 6 of the backend are not built yet, so the scheduler runs in the browser (`solve()` in `script.js`). It uses your subjects, assigned faculty, rooms and non-break time slots.

- A session needs a room whose `room_type` equals the subject's `required_room_type` and whose `capacity` fits the group's `student_count`.
- A subject with `requires_consecutive_slots` is placed in two adjacent slots.
- No group, teacher or room twice in a slot, one session of a subject per day, teachers at most 5 hours a day.
- The generated timetable is saved in the browser (`localStorage`), not in the database, until the backend gets timetable endpoints.

## Features

Build or rebuild the timetable, view it by group, teacher or room, find a better slot for any class, free-slot finder, live room status, attendance percentage, search (press Enter), CSV export, dark mode, green score, add/edit/delete for all five resources.

## Files

`index.html`, `style.css`, `script.js`. No dependencies.

## Limits

- Teacher and student role switch only changes the default view (there is no login).
- If a subject has several faculty assigned, the first is used.
- Attendance is stored in the browser only.
