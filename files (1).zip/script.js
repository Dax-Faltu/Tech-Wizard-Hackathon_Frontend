/* GreenCampus: talks to the Flask API (see README). Falls back to demo data if the backend is offline. */
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const DAYS=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'],COL=['green','blue','amber','purple'];
const E={subjects:'subjects',faculty:'faculty',classrooms:'classrooms',groups:'student-groups',slots:'time-slots'};
const t5=s=>String(s).slice(0,5),ap=s=>{const[h,m]=t5(s).split(':').map(Number);return(h%12||12)+':'+String(m).padStart(2,'0')+(h<12?' AM':' PM')};
const CFG={
 subjects:{t:'Subjects',cols:['name','code','department','semester','weekly_sessions','subject_type','required_room_type'],f:[['name'],['code'],['department'],['semester','number',1],['weekly_sessions','number',3],['duration_minutes','number',60],['subject_type','select',['theory','lab']],['required_room_type','select',['classroom','lab']],['requires_consecutive_slots','check']]},
 faculty:{t:'Faculty',as:1,cols:['name','department','email','designation'],f:[['name'],['department'],['email'],['designation']]},
 classrooms:{t:'Rooms',cols:['name','building','capacity','room_type','has_projector','has_computers'],f:[['name'],['building'],['capacity','number',40],['room_type','select',['classroom','lab']],['has_projector','check'],['has_computers','check']]},
 groups:{t:'Student groups',as:1,cols:['name','department','academic_year','semester','student_count'],f:[['name'],['department'],['academic_year','text','2024-25'],['semester','number',1],['student_count','number',40]]},
 slots:{t:'Time slots',cols:['day_of_week','start_time','end_time','is_break'],f:[['day_of_week','select',DAYS],['start_time','text','09:00'],['end_time','text','10:00'],['is_break','check']]}
};
let API=localStorage.gcApi||'http://localhost:5000/api',online=false,role='student',view='',tab='subjects',DB={},LOG=[],SEED=0,SL=new Map();

/* ---------- data layer ---------- */
function seed(){let id=0;const n=a=>a.map(o=>({id:++id,...o}));const slots=[];
 DAYS.slice(0,5).forEach(d=>[['09:00','10:00'],['10:00','11:00'],['11:00','12:00'],['12:00','13:00',1],['13:00','14:00'],['14:00','15:00'],['15:00','16:00']].forEach(([s,e,b])=>slots.push({id:++id,day_of_week:d,start_time:s,end_time:e,is_break:!!b})));
 const sub=(name,code,w,lab)=>({name,code,department:'CE',semester:1,weekly_sessions:w,duration_minutes:60,subject_type:lab?'lab':'theory',required_room_type:lab?'lab':'classroom',requires_consecutive_slots:!!lab});
 const subjects=n([sub('Engineering Math','MA101',3),sub('Data Structures','CE102',3),sub('Physics','PH103',2),sub('Communication','HS104',2),sub('Programming Lab','CE105',2,1)]);
 const fa=(name,d)=>({name,department:d,email:name.toLowerCase().replace(/[^a-z]/g,'')+'@uni.edu',designation:'Faculty'});
 const faculty=n([fa('Dr. Mehta','Maths'),fa('Prof. Shah','CE'),fa('Dr. Joshi','Physics'),fa('Ms. Patel','CE')]);
 const rm=(name,b,c,t)=>({name,building:b,capacity:c,room_type:t,has_projector:t==='classroom',has_computers:t==='lab'});
 const classrooms=n([rm('A-103','Block A',60,'classroom'),rm('B-204','Block B',72,'classroom'),rm('C-103','Block C',45,'classroom'),rm('Lab 2','Tech Block',40,'lab'),rm('Lab 3','Tech Block',40,'lab')]);
 const groups=n([{name:'CE-A',department:'CE',academic_year:'2024-25',semester:1,student_count:40},{name:'CE-B',department:'CE',academic_year:'2024-25',semester:1,student_count:38}]);
 const S=subjects.map(s=>s.id),F=faculty.map(f=>f.id);
 return{subjects,faculty,classrooms,groups,slots,seq:1000,as:{faculty:{[F[0]]:[S[0]],[F[1]]:[S[1]],[F[2]]:[S[2]],[F[3]]:[S[3],S[4]]},groups:{[groups[0].id]:S,[groups[1].id]:S}}}}
const persist=()=>{try{localStorage.gcDemo=JSON.stringify({...DB,tt:undefined})}catch(e){}};
async function req(m,p,b){const c=new AbortController(),tm=setTimeout(()=>c.abort(),3000);
 try{const r=await fetch(API+p,{method:m,headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined,signal:c.signal});
  if(r.status===204)return{};const j=await r.json().catch(()=>({}));
  if(!r.ok)throw new Error((j.message||'Request failed ('+r.status+')')+(j.details?': '+Object.entries(j.details).map(([k,v])=>k+' '+v).join(', '):''));return j}
 finally{clearTimeout(tm)}}
const api={
 async add(k,b){if(online){const r=await req('POST','/'+E[k],b);DB[k].push(r.data);return}DB[k].push({id:++DB.seq,...b});persist()},
 async upd(k,id,b){if(online){const r=await req('PATCH',`/${E[k]}/${id}`,b);Object.assign(DB[k].find(x=>x.id===id),r.data);return}Object.assign(DB[k].find(x=>x.id===id),b);persist()},
 async del(k,id){if(online)await req('DELETE',`/${E[k]}/${id}`);DB[k]=DB[k].filter(x=>x.id!==id);if(DB.as[k])delete DB.as[k][id];cleanTT();persist()},
 async setAs(k,id,ids){const cur=DB.as[k][id]||[],add=ids.filter(x=>!cur.includes(x)),rm=cur.filter(x=>!ids.includes(x));
  if(online){if(add.length)await req('POST',`/${E[k]}/${id}/subjects`,{subject_ids:add});for(const s of rm)await req('DELETE',`/${E[k]}/${id}/subjects/${s}`)}
  DB.as[k][id]=ids;persist()}};
function cleanTT(){const has=(k,id)=>id==null||DB[k].some(x=>x.id===id);SL=new Map(DB.slots.map(s=>[s.id,s]));
 DB.tt=(DB.tt||[]).filter(e=>has('groups',e.gid)&&has('subjects',e.sid)&&has('faculty',e.fid)&&has('classrooms',e.rid)&&SL.has(e.slotId));localStorage.gcTT=JSON.stringify(DB.tt)}
async function loadAll(){
 try{await req('GET','/health');online=true}catch(e){online=false}
 if(online){const old=DB.tt;DB={as:{faculty:{},groups:{}}};
  for(const k in E){let p=1,all=[];for(;;){const r=await req('GET',`/${E[k]}?page=${p}&per_page=100`);all.push(...r.data);if(!r.pagination||p>=r.pagination.total_pages)break;p++}DB[k]=all}
  for(const k of['faculty','groups'])await Promise.all(DB[k].map(async o=>{DB.as[k][o.id]=(await req('GET',`/${E[k]}/${o.id}/subjects`)).data.map(x=>x.id??x.subject_id??x)}))}
 else{try{DB=JSON.parse(localStorage.gcDemo)}catch(e){}if(!DB||!DB.subjects)DB=seed()}
 try{DB.tt=JSON.parse(localStorage.gcTT||'[]')}catch(e){DB.tt=[]}cleanTT()}

/* ---------- scheduler (constraint search) ---------- */
function days(){return DAYS.filter(d=>DB.slots.some(s=>s.day_of_week===d))}
function periods(){const m=new Map();DB.slots.forEach(s=>m.set(t5(s.start_time),{s:t5(s.start_time),e:t5(s.end_time)}));return[...m.values()].sort((a,b)=>a.s<b.s?-1:1)}
function solve(sd){const t0=performance.now();let rs=sd*7919+13;const rnd=()=>(rs=(rs*9301+49297)%233280)/233280;
 const ds=days(),by={};DB.slots.filter(s=>!s.is_break).sort((a,b)=>t5(a.start_time)<t5(b.start_time)?-1:1).forEach(s=>(by[s.day_of_week]=by[s.day_of_week]||[]).push(s));
 const pair=(d,i)=>{const a=by[d][i],b=by[d][i+1];return b&&t5(a.end_time)===t5(b.start_time)?[a,b]:null};
 const ss=[],issues=[];
 DB.groups.forEach(g=>(DB.as.groups[g.id]||[]).forEach(sid=>{const s=DB.subjects.find(x=>x.id===sid);if(!s)return;
  const fs=DB.faculty.filter(f=>(DB.as.faculty[f.id]||[]).includes(sid));if(!fs.length)issues.push(`${s.name} has no faculty assigned`);
  const rooms=DB.classrooms.filter(r=>r.room_type===s.required_room_type&&r.capacity>=g.student_count);
  if(!rooms.length){issues.push(`No ${s.required_room_type} fits ${g.name} for ${s.name}`);return}
  for(let k=0;k<s.weekly_sessions;k++)ss.push({g,s,f:fs[0]||null,rooms,len:s.requires_consecutive_slots?2:1})}));
 if(!ss.length||issues.some(x=>x.startsWith('No ')))return{ok:0,out:[],issues:issues.length?issues:['Assign subjects to at least one student group.']};
 ss.sort((a,b)=>b.len-a.len||b.s.weekly_sessions-a.s.weekly_sessions||rnd()-.5);
 const occ=new Set(),cnt={},out=[];let nodes=0;
 const go=i=>{if(i===ss.length)return 1;if(++nodes>200000)return 0;const{g,s,f,len,rooms}=ss[i];
  for(const d of ds.slice().sort((a,b)=>(cnt['g'+g.id+a]||0)-(cnt['g'+g.id+b]||0)||rnd()-.5)){
   if(cnt['s'+g.id+'|'+s.id+d]||(f&&(cnt['f'+f.id+d]||0)+len>5))continue;
   for(const k of(by[d]||[]).map((_,j)=>j).sort(()=>rnd()-.5)){const us=len===2?pair(d,k):[by[d][k]];if(!us)continue;
    if(us.some(u=>occ.has('g'+g.id+'|'+u.id)||(f&&occ.has('f'+f.id+'|'+u.id))))continue;
    for(const r of rooms.slice().sort(()=>rnd()-.5)){if(us.some(u=>occ.has('r'+r.id+'|'+u.id)))continue;
     const keys=us.flatMap(u=>['g'+g.id+'|'+u.id,'r'+r.id+'|'+u.id].concat(f?['f'+f.id+'|'+u.id]:[]));keys.forEach(x=>occ.add(x));
     cnt['s'+g.id+'|'+s.id+d]=1;cnt['g'+g.id+d]=(cnt['g'+g.id+d]||0)+len;if(f)cnt['f'+f.id+d]=(cnt['f'+f.id+d]||0)+len;
     us.forEach(u=>out.push({gid:g.id,sid:s.id,fid:f?f.id:null,rid:r.id,slotId:u.id,len}));
     if(go(i+1))return 1;
     keys.forEach(x=>occ.delete(x));cnt['s'+g.id+'|'+s.id+d]=0;cnt['g'+g.id+d]-=len;if(f)cnt['f'+f.id+d]-=len;out.length-=us.length}}}
  return 0};
 const ok=go(0);return{ok,out,issues,ms:Math.round(performance.now()-t0)}}
function clashes(){const m=new Set();let n=0;DB.tt.forEach(e=>[['g',e.gid],['f',e.fid],['r',e.rid]].forEach(([k,v])=>{if(v==null)return;const key=k+v+'|'+e.slotId;if(m.has(key))n++;m.add(key)}));return n}
function gen(quiet){const r=solve(++SEED);
 if(!r.ok){openModal('Could not build a timetable',`<p>${r.issues.length?r.issues.map(esc).join('<br>'):'No clash-free timetable was found within the search limit. Add a room, free up time slots or reduce weekly sessions.'}</p>`);return}
 DB.tt=r.out;cleanTT();LOG.unshift(`Timetable built in ${r.ms} ms (variation ${SEED})`);drawAll();
 if(!quiet)toast(r.issues.length?'Built, but: '+r.issues[0]:`Built in ${r.ms} ms with ${clashes()} clashes`)}

/* ---------- helpers ---------- */
const room=id=>DB.classrooms.find(r=>r.id===id),subj=id=>DB.subjects.find(s=>s.id===id),fac=id=>DB.faculty.find(f=>f.id===id),grp=id=>DB.groups.find(g=>g.id===id);
const inView=e=>{const[k,id]=[view[0],+view.slice(2)];return k==='g'?e.gid===id:k==='f'?e.fid===id:e.rid===id};
const todayName=()=>DAYS[(new Date().getDay()+6)%7];
function blocks(list){const out=[];list.map((e,i)=>({e,s:SL.get(e.slotId)})).filter(x=>x.s).sort((a,b)=>DAYS.indexOf(a.s.day_of_week)-DAYS.indexOf(b.s.day_of_week)||(t5(a.s.start_time)<t5(b.s.start_time)?-1:1)).forEach(x=>{
  const p=out[out.length-1];if(p&&p.e.sid===x.e.sid&&p.e.gid===x.e.gid&&p.day===x.s.day_of_week&&p.end===t5(x.s.start_time)){p.end=t5(x.s.end_time)}
  else out.push({e:x.e,day:x.s.day_of_week,start:t5(x.s.start_time),end:t5(x.s.end_time)})});return out}
function occupiedNow(){const n=new Date(),hm=String(n.getHours()).padStart(2,'0')+':'+String(n.getMinutes()).padStart(2,'0'),d=todayName(),set=new Set();
 DB.tt.forEach(e=>{const s=SL.get(e.slotId);if(s&&s.day_of_week===d&&t5(s.start_time)<=hm&&hm<t5(s.end_time))set.add(e.rid)});return set}
function nextBlock(bl){const n=new Date(),now=((n.getDay()+6)%7)*1440+n.getHours()*60+n.getMinutes();let best=null,bd=1e9;
 bl.forEach(b=>{const[h,m]=b.start.split(':').map(Number);let d=DAYS.indexOf(b.day)*1440+h*60+m-now;if(d<0)d+=7*1440;if(d<bd){bd=d;best=b}});return best}
function greenScore(){let ch=0,gaps=0;const n=DB.tt.length;DB.groups.forEach(g=>days().forEach(d=>{
  const bl=blocks(DB.tt.filter(e=>e.gid===g.id)).filter(b=>b.day===d);bl.forEach((b,i)=>{const p=bl[i-1];if(!p)return;if(room(p.e.rid)?.building!==room(b.e.rid)?.building)ch++;if(p.end!==b.start&&!(p.end<'13:00'&&b.start>='12:00'))gaps++})}));
 return n?Math.max(40,Math.round(100-(ch*4+gaps*2)/n*25)):0}

/* ---------- modal / toast ---------- */
function toast(m){const t=$('#toast');t.textContent=m;t.classList.add('show');clearTimeout(window.tt);window.tt=setTimeout(()=>t.classList.remove('show'),2600)}
function openModal(t,h){$('#modalContent').innerHTML=`<h2>${t}</h2>${h}`;$('#modalBackdrop').classList.add('show')}
function closeModal(){$('#modalBackdrop').classList.remove('show')}
const fail=e=>toast(e.name==='AbortError'?'Backend did not respond':e.message);

/* ---------- drawing ---------- */
function opts(){const o=[...DB.groups.map(g=>`<option value="g:${g.id}">Group ${esc(g.name)}</option>`),...DB.faculty.map(f=>`<option value="f:${f.id}">Teacher ${esc(f.name)}</option>`),...DB.classrooms.map(r=>`<option value="r:${r.id}">Room ${esc(r.name)}</option>`)];
 $('#groupSelect').innerHTML=o.join('');const ok=[...$('#groupSelect').options].some(x=>x.value===view);
 if(!ok)view=role==='student'?(DB.groups[0]?'g:'+DB.groups[0].id:''):(DB.faculty[0]?'f:'+DB.faculty[0].id:'');$('#groupSelect').value=view}
function drawAll(){opts();drawDash();drawWeek();drawPeople();drawRooms();drawData();drawInsights();const c=$('#conn');c.textContent=online?'Backend connected':'Demo mode (offline)';c.className='conn'+(online?' on':'')}
function drawDash(){const n=new Date(),h=n.getHours();$('#today').textContent=n.toLocaleDateString('en-US',{weekday:'long',month:'long',day:'2-digit',year:'numeric'}).toUpperCase().replace(',',' ·');
 $('#greeting').innerHTML=`Good ${h<12?'morning':h<17?'afternoon':'evening'}, ${role==='student'?'Vishwa':'Professor'} <span>🌱</span>`;
 const bl=blocks(DB.tt.filter(inView)),td=bl.filter(b=>b.day===todayName());
 $('#todayTimeline').innerHTML=td.map(b=>`<div class="timeline-row"><div class="time">${ap(b.start)}</div><div class="timeline-line"></div><div class="timeline-card"><b>${esc(subj(b.e.sid)?.name)}</b><small>${esc(room(b.e.rid)?.name)} · ${esc(fac(b.e.fid)?.name||'No faculty')}</small></div></div>`).join('')||'<p style="color:#78857f;font-size:11px">No classes today in this view.</p>';
 $('#sToday').textContent=td.length;const nb=nextBlock(bl);$('#sNext').textContent=nb?ap(nb.start):'-';$('#sNextN').textContent=nb?`${nb.day.slice(0,3)} · ${subj(nb.e.sid)?.name} · ${room(nb.e.rid)?.name}`:'Build a timetable first';
 $('#qAtt').textContent=nb?`${subj(nb.e.sid)?.name} · ${ap(nb.start)}`:'No class scheduled';
 const att=JSON.parse(localStorage.gcAtt||'[]');$('#sAtt').textContent=att.length?Math.round(att.reduce((a,b)=>a+b,0)/att.length)+'%':'-';$('#sAttN').textContent=att.length?att.length+' sessions marked':'no sessions marked';
 const occ=occupiedNow(),free=DB.classrooms.length-occ.size;$('#freeRooms').textContent=free;$('#freeN').textContent='of '+DB.classrooms.length+' rooms';$('#qRoom').textContent=free+' rooms currently free';
 const gs=greenScore();$('#greenScoreSide').textContent=gs+'%';$('#greenBarSide').style.width=gs+'%';$('#hb').textContent=clashes()}
function drawWeek(){const ds=days(),ps=periods();const g=$('#weekGrid');g.style.gridTemplateColumns=`72px repeat(${ds.length||1},1fr)`;
 let h='<div class="week-head"></div>'+ds.map(d=>`<div class="week-head">${d.slice(0,3).toUpperCase()}</div>`).join('');
 ps.forEach(p=>{h+=`<div class="time-cell">${ap(p.s)}</div>`;ds.forEach(d=>{const sl=DB.slots.find(s=>s.day_of_week===d&&t5(s.start_time)===p.s);
  if(sl&&sl.is_break){h+='<div class="class-cell"><div class="class-card purple"><b>Break</b></div></div>';return}
  const es=sl?DB.tt.map((e,i)=>({e,i})).filter(x=>x.e.slotId===sl.id&&inView(x.e)):[];
  h+='<div class="class-cell">'+es.map(({e,i})=>`<div class="class-card ${COL[e.sid%COL.length]}" data-e="${i}"><b>${esc(subj(e.sid)?.name)}</b><small>${esc(room(e.rid)?.name)} · ${esc(fac(e.fid)?.name||'')}</small></div>`).join('')+'</div>'})});
 g.innerHTML=h;const c=clashes();$('#hHead').textContent=c?`${c} clashes found`:'Schedule health: no clashes';$('#hSub').textContent=`${DB.tt.length} class slots placed · green score ${greenScore()}% · ${online?'live data':'demo data'}`}
function drawPeople(){$('#peopleGrid').innerHTML=DB.faculty.map(f=>`<div class="person"><div class="person-avatar">${esc(f.name.replace(/^(Dr|Prof|Ms|Mr)\.?\s/,'').slice(0,2).toUpperCase())}</div><div><b>${esc(f.name)}</b><small>${esc(f.department)} · ${esc(f.designation||'Faculty')}</small></div><i class="status"></i></div>`).join('')+DB.groups.map(g=>`<div class="person"><div class="person-avatar">${esc(g.name.slice(0,2).toUpperCase())}</div><div><b>${esc(g.name)}</b><small>${esc(g.department)} · Sem ${g.semester} · ${g.student_count} students</small></div><i class="status"></i></div>`).join('')}
function drawRooms(){const q=$('#roomSearch').value.toLowerCase(),cap=+$('#capacitySelect').value,av=$('#availableOnly').classList.contains('active'),occ=occupiedNow();
 const rs=DB.classrooms.filter(r=>(!q||(r.name+' '+r.building).toLowerCase().includes(q))&&r.capacity>=cap&&(!av||!occ.has(r.id)));
 $('#roomsGrid').innerHTML=rs.map(r=>`<div class="room"><div class="room-top"><div><b>${esc(r.name)}</b><small>${esc(r.building)}</small></div><span class="room-status ${occ.has(r.id)?'busy':''}">${occ.has(r.id)?'Occupied':'Available'}</span></div><div class="room-meta"><span>♙ ${r.capacity} seats</span><span>${esc(r.room_type)}</span>${r.has_projector?'<span>Projector</span>':''}${r.has_computers?'<span>PCs</span>':''}</div></div>`).join('')||'<div class="panel" style="padding:25px;grid-column:1/-1"><b>No rooms match these filters.</b></div>'}
function drawInsights(){const gs=greenScore(),ds=days(),per=DB.slots.filter(s=>!s.is_break&&s.day_of_week===ds[0]).length||1;
 $('#ringN').textContent=gs;$('#ring').style.background=`conic-gradient(#62a875 0 ${gs}%,#e3eee5 ${gs}%)`;
 $('#ringTxt').textContent=DB.tt.length?`Calculated from room-to-room building changes and gaps between classes across ${DB.groups.length} groups. Higher means less walking and fewer idle gaps.`:'Build a timetable to see your green score.';
 $('#bars').innerHTML=ds.map(d=>{const n=DB.tt.filter(e=>SL.get(e.slotId)?.day_of_week===d).length;return`<div><i style="height:${Math.min(100,Math.round(n/(per*Math.max(1,DB.groups.length))*100))}%"></i><span>${d.slice(0,3)}</span></div>`}).join('');
 const use=DB.classrooms.map(r=>({r,n:DB.tt.filter(e=>e.rid===r.id).length})).sort((a,b)=>a.n-b.n),fl=DB.faculty.map(f=>({f,n:DB.tt.filter(e=>e.fid===f.id).length})).sort((a,b)=>b.n-a.n),R=[];
 if(use[0])R.push([`Open ${use[0].r.name} for self-study`,`Only ${use[0].n} of ${DB.slots.filter(s=>!s.is_break).length} slots are used.`]);
 if(fl[0])R.push([`${fl[0].f.name} teaches the most`,`${fl[0].n} hours this week. Check the load before adding classes.`]);
 R.push(['Check the clash radar after edits',`${clashes()} clashes right now.`]);
 $('#recs').innerHTML=R.map((r,i)=>`<div class="recommend"><span>0${i+1}</span><div><b>${esc(r[0])}</b><small>${esc(r[1])}</small></div><button onclick="this.closest('.recommend').remove()">Done</button></div>`).join('')}
function drawData(){const c=CFG[tab];$('#tabs').innerHTML=Object.keys(CFG).map(k=>`<button class="filter${k===tab?' active':''}" data-tab="${k}">${CFG[k].t}</button>`).join('');
 $('#dataSub').textContent=`${DB[tab].length} ${c.t.toLowerCase()} · ${online?'saved to the backend':'saved in this browser (demo)'}`;
 $('#tbl').innerHTML=`<tr>${c.cols.map(x=>`<th>${x.replace(/_/g,' ')}</th>`).join('')}<th></th></tr>`+(DB[tab].map(r=>`<tr>${c.cols.map(x=>`<td>${esc(typeof r[x]==='boolean'?(r[x]?'Yes':'No'):r[x])}</td>`).join('')}<td class="act">${c.as?`<button data-as="${r.id}">Subjects (${(DB.as[tab][r.id]||[]).length})</button>`:''}<button data-ed="${r.id}">Edit</button><button data-rm="${r.id}">Delete</button></td></tr>`).join('')||'<tr><td colspan="9">Nothing here yet. Press Add.</td></tr>')}

/* ---------- forms ---------- */
function form(row){const c=CFG[tab];openModal((row?'Edit ':'Add ')+c.t.toLowerCase(),`<form class="fm" id="fm">${c.f.map(([n,ty,o])=>{const v=row?row[n]:(ty==='select'?o[0]:o);
 return ty==='check'?`<label class="ck"><input type="checkbox" name="${n}" ${v?'checked':''}> ${n.replace(/_/g,' ')}</label>`:ty==='select'?`<label>${n.replace(/_/g,' ')}<select name="${n}">${o.map(x=>`<option ${x===v?'selected':''}>${x}</option>`).join('')}</select></label>`:`<label>${n.replace(/_/g,' ')}<input name="${n}" type="${ty||'text'}" value="${esc(v??'')}" required></label>`}).join('')}<p class="fe" id="fe"></p><button class="primary" type="submit">Save</button></form>`);
 $('#fm').onsubmit=async e=>{e.preventDefault();const b={};c.f.forEach(([n,ty])=>{const el=e.target.elements[n];b[n]=ty==='check'?el.checked:ty==='number'?+el.value:el.value.trim()});
  try{row?await api.upd(tab,row.id,b):await api.add(tab,b);closeModal();cleanTT();drawAll();toast('Saved')}catch(x){$('#fe').textContent=x.name==='AbortError'?'Backend did not respond':x.message}}}
function assignModal(id){const k=tab,cur=DB.as[k][id]||[];openModal('Assign subjects',`<div class="modal-list">${DB.subjects.map(s=>`<label class="modal-option"><div><b>${esc(s.name)}</b><small>${esc(s.code)}</small></div><input type="checkbox" value="${s.id}" ${cur.includes(s.id)?'checked':''}></label>`).join('')||'<p>Add subjects first.</p>'}</div><button class="primary" id="asSave">Save</button>`);
 $('#asSave').onclick=async()=>{try{await api.setAs(k,id,$$('#modalContent input:checked').map(x=>+x.value));closeModal();drawAll();toast('Assignments saved. Build the timetable to apply them.')}catch(x){fail(x)}}}

/* ---------- swaps, free slots, attendance ---------- */
function slotFree(e,s){return!DB.tt.some(o=>o.slotId===s.id&&(o.gid===e.gid||(e.fid!=null&&o.fid===e.fid)||o.rid===e.rid))}
function swapFor(i){const e=DB.tt[i];if(e.len===2)return openModal('Lab block','<p>Labs are 2-hour blocks. Build the timetable again to reshuffle them.</p>');
 const alt=DB.slots.filter(s=>!s.is_break&&s.id!==e.slotId&&slotFree(e,s)&&!DB.tt.some(o=>o.gid===e.gid&&o.sid===e.sid&&SL.get(o.slotId).day_of_week===s.day_of_week)).slice(0,6);
 openModal('Move '+esc(subj(e.sid)?.name),`<p>Slots where the group, teacher and room are all free:</p><div class="modal-list">${alt.map(s=>`<div class="modal-option"><div><b>${s.day_of_week} · ${ap(s.start_time)}</b><small>${esc(room(e.rid)?.name)}</small></div><button data-mv="${i}|${s.id}">Move here</button></div>`).join('')||'<p>No free slot keeps every constraint valid.</p>'}</div>`)}
function csv(){const q=s=>'"'+String(s??'').replace(/"/g,'""')+'"';return['group,day,start,end,subject,faculty,room',...DB.tt.map(e=>{const s=SL.get(e.slotId);return[q(grp(e.gid)?.name),s.day_of_week,t5(s.start_time),t5(s.end_time),q(subj(e.sid)?.name),q(fac(e.fid)?.name),q(room(e.rid)?.name)].join(',')})].join('\n')}

/* ---------- events ---------- */
function go(id){$$('.section').forEach(s=>s.classList.toggle('active',s.id===id));$$('.nav-item').forEach(n=>n.classList.toggle('active',n.dataset.section===id));window.scrollTo({top:0,behavior:'smooth'})}
$$('.nav-item').forEach(n=>n.onclick=()=>go(n.dataset.section));$$('[data-section-jump]').forEach(n=>n.onclick=()=>go(n.dataset.sectionJump));
document.addEventListener('click',async e=>{const b=e.target.closest('[data-tab],[data-as],[data-ed],[data-rm],[data-e],[data-mv]');if(!b)return;const d=b.dataset;
 if(d.tab){tab=d.tab;drawData()}
 else if(d.as)assignModal(+d.as);
 else if(d.ed)form(DB[tab].find(x=>x.id===+d.ed));
 else if(d.rm){if(confirm('Delete this item?'))try{await api.del(tab,+d.rm);drawAll();toast('Deleted')}catch(x){fail(x)}}
 else if(d.e){const x=DB.tt[+d.e],s=SL.get(x.slotId);openModal(esc(subj(x.sid)?.name),`<div class="modal-list"><div class="modal-option"><div><b>When</b><small>${s.day_of_week} · ${ap(s.start_time)}</small></div></div><div class="modal-option"><div><b>Room</b><small>${esc(room(x.rid)?.name)} · ${esc(room(x.rid)?.building)}</small></div></div><div class="modal-option"><div><b>Teacher and group</b><small>${esc(fac(x.fid)?.name||'Unassigned')} · ${esc(grp(x.gid)?.name)}</small></div><button onclick="swapFor(${+d.e})">Find better slot</button></div></div>`)}
 else if(d.mv){const[i,sid]=d.mv.split('|').map(Number);DB.tt[i].slotId=sid;cleanTT();closeModal();drawAll();toast('Class moved. '+clashes()+' clashes.')}});
$('#roleSwitch').onclick=()=>{role=role==='student'?'teacher':'student';$('#roleText').textContent=role==='student'?'Student View':'Teacher View';view='';drawAll();toast('Switched to '+role+' view')};
$('#autoBtn').onclick=$('#generateBtn').onclick=()=>gen();$('#roomOptimizeBtn').onclick=()=>{gen();go('timetable')};
$('#groupSelect').onchange=e=>{view=e.target.value;drawAll()};$('#addBtn').onclick=()=>form();
$('#findSlotBtn').onclick=()=>{const g=view[0]==='g'?+view.slice(2):DB.groups[0]?.id,fr=DB.slots.filter(s=>!s.is_break&&!DB.tt.some(e=>e.gid===g&&e.slotId===s.id));
 openModal('Free slots for '+esc(grp(g)?.name),`<div class="modal-list">${fr.slice(0,8).map(s=>`<div class="modal-option"><div><b>${s.day_of_week} · ${ap(s.start_time)}</b><small>${DB.classrooms.filter(r=>!DB.tt.some(e=>e.rid===r.id&&e.slotId===s.id)).length} rooms free</small></div></div>`).join('')||'<p>No free slots.</p>'}</div>`)};
$('#attendanceBtn').onclick=()=>{const nb=nextBlock(blocks(DB.tt.filter(inView)));if(!nb)return toast('No class to mark yet');const g=grp(nb.e.gid),n=g?g.student_count:0;
 openModal('Mark attendance',`<p>${esc(subj(nb.e.sid)?.name)} · ${nb.day} ${ap(nb.start)} · ${esc(g?.name)}</p><input class="in" id="pres" type="number" min="0" max="${n}" value="${n}"><p>Students present out of ${n}</p><button class="primary" id="attSave">Save</button>`);
 $('#attSave').onclick=()=>{const a=JSON.parse(localStorage.gcAtt||'[]');a.push(n?Math.round(+$('#pres').value/n*100):0);localStorage.gcAtt=JSON.stringify(a);closeModal();drawDash();toast('Attendance saved')}};
$('#swapBtn').onclick=()=>{const bl=DB.tt.map((e,i)=>({e,i})).filter(x=>inView(x.e)&&x.e.len===1).slice(0,8);openModal('Smart swap',`<p>Pick a class to find slots that keep every constraint valid.</p><div class="modal-list">${bl.map(({e,i})=>`<div class="modal-option"><div><b>${esc(subj(e.sid)?.name)}</b><small>${SL.get(e.slotId).day_of_week} · ${ap(SL.get(e.slotId).start_time)}</small></div><button onclick="swapFor(${i})">Find slots</button></div>`).join('')||'<p>Build a timetable first.</p>'}</div>`)};
$('#roomBtn').onclick=()=>go('rooms');
$('#noticeBtn').onclick=$('#notifyBtn').onclick=()=>openModal('Campus notices',`<div class="modal-list"><div class="modal-option"><div><b>${online?'Backend connected':'Demo mode'}</b><small>${esc(API)}</small></div></div>${LOG.slice(0,5).map(x=>`<div class="modal-option"><div><b>${esc(x)}</b></div></div>`).join('')}</div>`);
$('#explainBtn').onclick=()=>openModal('Why this schedule?',`<p>Every class was placed by a constraint search.</p><div class="modal-list"><div class="modal-option"><div><b>Hard rules</b><small>No group, teacher or room is booked twice. Labs use lab rooms, rooms fit the group, subjects get one session per day.</small></div><span>${clashes()} clashes</span></div><div class="modal-option"><div><b>Soft goals</b><small>Spread each group's week and limit teachers to 5 hours a day.</small></div></div></div>`);
$('#exportBtn').onclick=()=>{if(!DB.tt.length)return toast('Build a timetable first');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv()],{type:'text/csv'}));a.download='timetable.csv';a.click();toast('Timetable CSV downloaded')};
$('#inviteBtn').onclick=()=>{tab='faculty';go('data');drawData();form()};
$('#availableOnly').onclick=()=>{$('#availableOnly').classList.toggle('active');drawRooms()};$('#roomSearch').oninput=drawRooms;$('#capacitySelect').onchange=drawRooms;
$('#modalClose').onclick=closeModal;$('#modalBackdrop').onclick=e=>{if(e.target.id==='modalBackdrop')closeModal()};
$('#themeBtn').onclick=()=>{document.body.classList.toggle('dark');toast(document.body.classList.contains('dark')?'Dark mode on':'Light mode on')};
$('#globalSearch').onkeydown=e=>{if(e.key!=='Enter')return;const q=e.target.value.trim().toLowerCase();if(!q)return;
 const hit=[...DB.subjects.map(x=>['Subject',x.name]),...DB.faculty.map(x=>['Teacher',x.name]),...DB.classrooms.map(x=>['Room',x.name+' · '+x.building]),...DB.groups.map(x=>['Group',x.name])].filter(x=>x[1].toLowerCase().includes(q));
 openModal('Search: '+esc(q),`<div class="modal-list">${hit.map(h=>`<div class="modal-option"><div><b>${esc(h[1])}</b><small>${h[0]}</small></div></div>`).join('')||'<p>No matches.</p>'}</div>`)};
const settings=()=>openModal('Settings',`<p>${online?'Connected to the Flask backend.':'The backend is not reachable, so demo data is shown.'}</p><label style="font-size:10px">API base URL</label><input class="in" id="apiUrl" value="${esc(API)}"><div style="display:flex;gap:8px;margin-top:12px"><button class="primary" id="apiSave">Save and reconnect</button><button class="secondary" id="demoReset">Reset demo data</button></div>`)||0;
$('#settingsBtn').onclick=$('#conn').onclick=()=>{settings();$('#apiSave').onclick=async()=>{API=$('#apiUrl').value.trim().replace(/\/$/,'');localStorage.gcApi=API;closeModal();await boot();toast(online?'Connected to backend':'Backend not reachable. Using demo data.')};$('#demoReset').onclick=async()=>{localStorage.removeItem('gcDemo');localStorage.removeItem('gcTT');online=false;closeModal();await boot();toast('Demo data reset')}};
async function boot(){$('#conn').textContent='Connecting…';try{await loadAll()}catch(e){online=false;DB=seed();DB.tt=[];toast('Backend error: '+e.message+'. Using demo data.')}
 cleanTT();if(!DB.tt.length&&DB.groups.length&&DB.subjects.length)gen(true);drawAll()}
boot();
